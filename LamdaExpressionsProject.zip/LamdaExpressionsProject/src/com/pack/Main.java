package com.pack;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Example d1=()->{  
	            System.out.println("Drawing");  
	        };  
	        d1.draw();
	        Example1 d=(a)->{  
	            System.out.println("the value is: "+a);  
	        }; 
	        d.print(10);
	        Example2 d2=(a,b)->{
	        	System.out.println("the sum is: "+(a+b));
	        };
	        d2.sum(10,20);
	}

}
