package com.pack;

public interface Example1 {
	public void print(int a);
}
