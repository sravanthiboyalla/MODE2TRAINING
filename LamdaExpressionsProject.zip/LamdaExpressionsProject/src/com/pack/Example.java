package com.pack;

public interface Example {
	public void draw(); 

}
