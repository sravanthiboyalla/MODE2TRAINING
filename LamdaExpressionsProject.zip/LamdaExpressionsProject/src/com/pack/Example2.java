package com.pack;

public interface Example2 {
	public void sum(int a,int b);
}
