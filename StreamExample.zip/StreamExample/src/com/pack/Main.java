package com.pack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;


public class Main {

	public static void main(String[] args) {
		ArrayList<Customer> a = new ArrayList<Customer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Account numbers");
		int n = sc.nextInt();
		ArrayList<Integer> b = new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			int k = sc.nextInt();
			
			b.add(k);
		}
		List<String> c = b.stream().map(i -> "sbi" + i).collect(Collectors.toList());
		List<String> valid = c.stream().filter(p -> (p.length() == 8)).collect(Collectors.toList());
		System.out.println(valid);
		long invalid=c.stream().filter(p -> (p.length() != 8)).count();
		System.out.println(invalid);
		for(int i=0;i<valid.size();i++)
		{
			String name=sc.next();
			int age=sc.nextInt();
			String phoneNumber=sc.next();
			a.add(new Customer(name,age,phoneNumber));
		}
		List<Customer> customer=a.stream().filter(k->(k.getName().matches("[A-Z][a-z]*"))&&
				(k.getAge()>18)&&(k.getPhoneNumber().matches("[6-9][0-9]{9}"))).collect(Collectors.toList());
		for(int i=0;i<(customer.size())&&i<valid.size();i++)
		{
			String accNum=valid.get(i);
			customer.get(i).setAccNum(accNum);
		}
		List<Customer> sortedList =customer.stream().sorted(Comparator.comparing(Customer::getName)).collect(Collectors.toList());
		System.out.println(sortedList);
	}
}
