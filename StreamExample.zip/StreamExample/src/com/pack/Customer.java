package com.pack;

public class Customer {
	String name;
	int age;
	String phoneNumber;
	private String accNum;	
	public Customer(String name, int age, String phoneNumber) {
		super();
		this.name = name;
		this.age = age;
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAccNum() {
		// TODO Auto-generated method stub
		return accNum;
	}
	public void setAccNum(String accNum) {
		// TODO Auto-generated method stub
		this.accNum=accNum;
	}
	
	@Override
	public String toString() {
		return "Customer [ACCNUM=" + accNum + ", name=" + name + ", age=" + age + ", phoneNumber=" + phoneNumber + "]";
	}
	
}
