package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dao.Student;
import com.example.demo.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	StudentService studentServicce;
	@GetMapping("/getAll")
	public ResponseEntity<List<Student>> getAllStudents()
	{
		return new ResponseEntity<List<Student>>(studentServicce.getAllStudents(),HttpStatus.OK);
	}
	@PostMapping("/")
	public ResponseEntity<Student> addStudents(@RequestBody Student student)
	{
		return new ResponseEntity<Student>(studentServicce.createStudents(student),HttpStatus.OK);
	}
	@PostMapping("/saveAll")
	public ResponseEntity<List<Student>> addMultiple(@RequestBody List<Student> student)
	{
		return new ResponseEntity<List<Student>>(studentServicce.createStudentsMultiple(student),HttpStatus.OK);
	}
	@GetMapping("/{studentId}")
	public ResponseEntity<Student> getStudentById(@PathVariable Long studentId)
	{
		return new ResponseEntity<Student>(studentServicce.getStudentsById(studentId),HttpStatus.OK);
	}

	/*
	 * @PutMapping("/{studentId}") public ResponseEntity<Student>
	 * updateStudentById(@PathVariable Long studentId,@RequestBody Student student )
	 * { return new
	 * ResponseEntity<Student>(studentServicce.updateStudentById(studentId),
	 * HttpStatus.OK);
	 * 
	 * }
	 */
	@DeleteMapping("/{studentId}")
	public ResponseEntity<String> deleteStudents(@PathVariable Long studentId)
	{
		return new ResponseEntity<String>(studentServicce.deleteStudent(studentId),HttpStatus.OK);
	}
	@DeleteMapping("/")
	public ResponseEntity<String> deleteStudents(@RequestBody List<Student> student)
	{
		return new ResponseEntity<String>(studentServicce.deleteStudents(student),HttpStatus.OK);
	}
	@GetMapping("/count")
	public ResponseEntity<Long> countStudents()
	{
		return new ResponseEntity<Long>(studentServicce.countStudents(),HttpStatus.OK);
	}
}
