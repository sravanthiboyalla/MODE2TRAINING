package com.example.demo.REpository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Dao.Student;

public interface StudentRepository extends JpaRepository<Student,Long>{

}
