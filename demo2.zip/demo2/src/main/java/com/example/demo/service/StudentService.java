package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.Student;
import com.example.demo.REpository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;
	public Student createStudents(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}
	public Student getStudentsById(Long studentId) {
		// TODO Auto-generated method stub
		return studentRepository.getById(studentId);
	}
	public List<Student> createStudentsMultiple(List<Student> student) {
		// TODO Auto-generated method stub
		return studentRepository.saveAll(student);
	}
	public String deleteStudent(Long studentId) {
		// TODO Auto-generated method stub
		studentRepository.deleteById(studentId);
		return "deleted successfully";
	}
	public String deleteStudents(List<Student> student) {
		// TODO Auto-generated method stub
		studentRepository.deleteAll(student);
		return "deleted students Successfully";
	}
	public Long countStudents() {
		// TODO Auto-generated method stub
		return studentRepository.count();
	}
	
}
