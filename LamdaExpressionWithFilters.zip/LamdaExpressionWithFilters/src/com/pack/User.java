package com.pack;

public class User {
	int userId;
	String userName;
	int age;
	public User(int userId, String userName, int age) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.age = age;
	}
	
}
