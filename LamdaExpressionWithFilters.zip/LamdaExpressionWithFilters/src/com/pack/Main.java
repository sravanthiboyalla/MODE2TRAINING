package com.pack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<User> list=new ArrayList<User>(); 
		list.add(new User(1,"sravanthi",21));
		list.add(new User(2,"sudhakar",19));
		list.add(new User(3,"vishnu",7));
		list.add(new User(4,"dhanush",17));
		Stream<User> filtered_data = list.stream().filter(p -> (p.userName).startsWith("s"));
		 filtered_data.forEach(  
	                user -> System.out.println(user.userName+": "+user.age));  
	}

}
