package com.pack;

public class MethodReferenceWithoutArguments {
	public static void m1()
	{
		System.out.println("hi");
	}
	public static void main(String[] args)
	{
		Runnable r=MethodReferenceWithoutArguments::m1;
		Thread t=new Thread(r);
		t.start();
		System.out.println("main");
	}
}
