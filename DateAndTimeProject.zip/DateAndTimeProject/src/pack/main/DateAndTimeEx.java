package pack.main;
import java.time.*;

public class DateAndTimeEx {
	public static void main(String[] args)
	{
		DateAndTimeEx s=new DateAndTimeEx();
		s.findLocalDateAndTime();
	}
	public static void findLocalDateAndTime()
	{
		LocalDateTime datetime=LocalDateTime.now();
		System.out.println(datetime);
		LocalDate date=datetime.toLocalDate();
		System.out.println(date);
		Month m=datetime.getMonth();
		System.out.println(m);
		int d=datetime.getDayOfMonth();
		System.out.println(d);
		int year=datetime.getDayOfYear();
		System.out.println(year);
		DayOfWeek dayOfWeek=datetime.getDayOfWeek();
		System.out.println(dayOfWeek);
		
	}
}
