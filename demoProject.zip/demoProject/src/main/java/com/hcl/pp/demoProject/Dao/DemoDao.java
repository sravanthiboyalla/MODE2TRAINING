package com.hcl.pp.demoProject.Dao;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hcl.pp.demoProject.model.Demo;

@Repository
public interface DemoDao extends PagingAndSortingRepository<Demo,Integer>{

}
