package com.hcl.pp.demoProject.Dao;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.hcl.pp.demoProject.model.Transaction;

@Repository
public interface TransactionDao extends PagingAndSortingRepository<Transaction, Integer> {

}
