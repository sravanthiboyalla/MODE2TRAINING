package com.hcl.pp.demoProject.Dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.pp.demoProject.model.Benifits;
@Repository
public interface BenifitDao extends CrudRepository<Benifits, String> {

	public Optional<Benifits> findByIfscCode(String ifscCode);
	public Optional<Benifits> findByIfscCodeAndCustId(String ifscCode, Integer custId);

}
