package com.hcl.pp.demoProject.services.impl;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.pp.demoProject.Dao.AccountDao;
import com.hcl.pp.demoProject.model.Account;
@Service
public class AccountServiceImpl {
	@Autowired
	AccountDao accountDao;
	Account account=new Account();
	//this method is used to add details to the database
	public void addAccountDetails(Account account) {
		accountDao.save(account);
	}
	//this  method is used to get details of the particular record
	public Optional<Account> getDetails(String i) {
		// TODO Auto-generated method stub
		return accountDao.findById(i);
	}
}
