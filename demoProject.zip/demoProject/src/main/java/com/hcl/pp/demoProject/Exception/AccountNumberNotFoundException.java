package com.hcl.pp.demoProject.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AccountNumberNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public AccountNumberNotFoundException(String exception) {
		super(exception);
	}
}
