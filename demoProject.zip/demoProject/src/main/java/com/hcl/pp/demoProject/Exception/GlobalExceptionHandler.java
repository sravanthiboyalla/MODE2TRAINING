package com.hcl.pp.demoProject.Exception;

import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;


@ControllerAdvice
@RestController
public class GlobalExceptionHandler {
	@ExceptionHandler(InsufficientBalanceException.class)
	public ResponseEntity<ErrorMessage> handleException(InsufficientBalanceException exception, WebRequest request) {
		ErrorMessage errorMessage = 
				new ErrorMessage(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(AccountNumberNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(AccountNumberNotFoundException exception, WebRequest request) {
		ErrorMessage errorMessage = 
				new ErrorMessage(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);
	}
}
