package com.hcl.pp.demoProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.pp.demoProject.Dto.SaveMoney;
import com.hcl.pp.demoProject.model.Transaction;
import com.hcl.pp.demoProject.services.impl.TransactionServiceImpl;

@RestController
public class TransactionController {
	@Autowired
	TransactionServiceImpl transactionService;
	@PostMapping("transaction/add")
	public void addDemoDetails(@RequestBody Transaction transaction) {;
	transactionService.addTransactionDetails(transaction);
	}
	@PostMapping("transaction/check")
	public String doTransaction(@RequestBody SaveMoney money) {
		String status=transactionService.checkBalance(money);
		return status;
	}
	@GetMapping("transaction/paging")
    public ResponseEntity<List<Transaction>> getAllTransactions(

                        @RequestParam(defaultValue = "1") Integer pageNo, 

                        @RequestParam(defaultValue = "10") Integer pageSize,
                        @RequestParam(defaultValue = "accountNumber") String sortBy)

    {

        List<Transaction> list = transactionService.getAllTransactions(pageNo, pageSize,sortBy);

 

        return new ResponseEntity<List<Transaction>>(list, new HttpHeaders(), HttpStatus.OK); 

    }
}
