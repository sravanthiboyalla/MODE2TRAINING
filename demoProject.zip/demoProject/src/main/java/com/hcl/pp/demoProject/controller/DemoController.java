package com.hcl.pp.demoProject.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.pp.demoProject.model.Demo;
import com.hcl.pp.demoProject.services.impl.DemoDaompl;

@RestController
public class DemoController {
	@Autowired
	DemoDaompl demoServices;

	@PostMapping("demo/add")
	public void addDemoDetails(@RequestBody Demo demo) {
		if ((demo.getAge() >= 18) && (demo.getAccountNumber().length() == 6)) {
			System.out.println("Data inserted successfully");
			demoServices.addDemoDetails(demo);
		} else {
			System.out.println("sorry!please enter data in correct format");
		}
	}

	@PostMapping("demo/update")
	public void updateDemoDetails(@RequestBody Demo demo) {
		if ((demo.getAge() >= 18) && (demo.getAccountNumber().length() == 6)) {
			System.out.println("Data updated successfully");
			demoServices.updateDemoDetails(demo);
		} else {
			System.out.println("sorry!please update data in correct format");
		}
	}

	@GetMapping("demo/delete")
	public void deleteDemoDetails(@RequestParam Integer id) {
			System.out.println("Data deleted successfully");
			demoServices.deleteDemoDetails(id);
	}
	@GetMapping("demo/get")
	public Optional<Demo> getDemoDetails(@RequestParam Integer id)
	{
		System.out.println("get demo data successfully");
		return  demoServices.getDetails(id);
	}
	@GetMapping("demo/ga")
	public Iterable<Demo> getAllDetails()
	{
		return demoServices.getd();
	}
	
}
