package com.hcl.pp.demoProject.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="demo1")
public class Demo implements Serializable{	
	@Id
	private Integer id;
	private String name;
	private Integer age;
	private String password;
	private String emailid;
	private String phoneNumber;
	private String accountNumber;
	private String job;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Demo() {
		super();
	}
	@Override
	public String toString() {
		return "Demo [id=" + id + ", name=" + name + ", age=" + age + ", password=" + password + ", emailid=" + emailid
				+ ", phoneNumber=" + phoneNumber + ", accountNumber=" + accountNumber + ", job=" + job + "]";
	}
}
