package com.hcl.pp.demoProject.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.pp.demoProject.model.Benifits;
import com.hcl.pp.demoProject.services.impl.BenifitService;

@RestController
public class BenifitController {
	@Autowired
	BenifitService benifitService;
	
	@PostMapping("benifit/add")
	public void addDemoDetails(@RequestBody Benifits benifit) {
		benifitService.addBenifitDetails(benifit);
	}
	@GetMapping("benifit/get")
	public Optional<Benifits> getBenifisDetails(@RequestParam String ifscCode)
	{
		System.out.println("get demo data successfully");
		return  benifitService.getBenifisDetails(ifscCode);
	}
	@GetMapping("benifit/getdetails")
	public Optional<Benifits> getBenifisDetails(@RequestParam String ifscCode,@RequestParam Integer custId)
	{
		System.out.println("get demo data successfully");
		return  benifitService.getBenifisDetails(ifscCode,custId);
	}
}
