package com.hcl.pp.demoProject.services.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.hcl.pp.demoProject.Dao.AccountDao;
import com.hcl.pp.demoProject.Dao.TransactionDao;
import com.hcl.pp.demoProject.Dto.SaveMoney;
import com.hcl.pp.demoProject.Exception.AccountNumberNotFoundException;
import com.hcl.pp.demoProject.Exception.InsufficientBalanceException;
import com.hcl.pp.demoProject.model.Account;
import com.hcl.pp.demoProject.model.Transaction;

@Service
public class TransactionServiceImpl {

	@Autowired
	TransactionDao transactionDao;
	@Autowired
	AccountDao accountDao;

	ModelMapper mapper = new ModelMapper();

	List<SaveMoney> list = new ArrayList<SaveMoney>();
	//add details to the database
	public void addTransactionDetails(Transaction transaction) {
		transactionDao.save(transaction);
	}
	//this method is used to done transaction
	public String checkBalance(SaveMoney money) {
		// TODO Auto-generated method stub
		Account a = new Account();
		list.add(mapper.map(a, SaveMoney.class));
		Account a1 = accountDao.findById(money.getFromAccount()).orElse(null);
		Account a2 = accountDao.findById(money.getToAccount()).orElse(null);
		if (a1 == null || a2 == null) {
			throw new AccountNumberNotFoundException("Account Number not found");
		}
		if (a1.getAmount() > money.getBalance()) {
			@SuppressWarnings("unused")
			String str1 = toTransaction(money, a2);
			String str = addTransaction(money, a1);
			return str;
		} else {
			throw new InsufficientBalanceException("InsufficientBalance");
		}
	}
	//this method is used to update the details of account a1
	public String addTransaction(SaveMoney money, Account a1) {
		Transaction t = new Transaction();
		t.setAccountNumber(money.getFromAccount());
		t.setAmount(money.getBalance());
		t.setType("credit");
		t.setDescription("sent");
		transactionDao.save(t);
		int amount = a1.getAmount() - money.getBalance();
		System.out.println(amount);
		a1.setAmount(amount);
		accountDao.save(a1);
		return "Transaction successfully";
	}
	//this method is used to update the details of account a2
	public String toTransaction(SaveMoney money, Account a2) {
		Transaction t = new Transaction();
		t.setAccountNumber(money.getToAccount());
		t.setAmount(money.getBalance());
		t.setType("debit");
		t.setDescription("received");
		transactionDao.save(t);
		System.out.println(a2.getAmount());
		System.out.println(money.getBalance());
		int amount = a2.getAmount() + money.getBalance();
		System.out.println(money.getBalance());
		System.out.println(amount);
		a2.setAmount(amount);
		accountDao.save(a2);
		return "Transaction successfully";
	}
	//this method is used for paging
	public List<Transaction> getAllTransactions(Integer pageNo, Integer pageSize, String accountNumber) {
		// TODO Auto-generated method stub
		PageRequest paging = PageRequest.of(pageNo, pageSize, Sort.by(accountNumber));

		Page<Transaction> pagedResult = transactionDao.findAll(paging);

		if (pagedResult.hasContent()) {
			return pagedResult.getContent();

		} else {

			return new ArrayList<Transaction>();

		}
	}

}
