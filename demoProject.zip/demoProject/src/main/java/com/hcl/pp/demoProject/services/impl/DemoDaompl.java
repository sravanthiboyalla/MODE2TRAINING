package com.hcl.pp.demoProject.services.impl;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.pp.demoProject.Dao.DemoDao;
import com.hcl.pp.demoProject.model.Demo;

@Service
public class DemoDaompl {
	@Autowired
	DemoDao demos;
	//add details to the database
	public void addDemoDetails(Demo demo) {
		demos.save(demo);
	}
	//update details to the database
	public void updateDemoDetails(Demo demo) {
		demos.save(demo);
	}
	//delete details from the database
	public void deleteDemoDetails(Integer i) {
		demos.deleteById(i);
	}
	//get details from the data base for one record
	public Optional<Demo> getDetails(Integer i) {
		// TODO Auto-generated method stub
		return demos.findById(i);
	}
	//get all records from the database
	public Iterable<Demo> getd() {
		return demos.findAll();
		// TODO Auto-generated method stub
	}
}
