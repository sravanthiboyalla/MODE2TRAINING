package com.hcl.pp.demoProject.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.pp.demoProject.model.Account;

import com.hcl.pp.demoProject.services.impl.AccountServiceImpl;

@RestController
public class AccountController {
	@Autowired
	AccountServiceImpl accountService;

	@PostMapping("account/add")
	public void addDemoDetails(@RequestBody Account account) {
		accountService.addAccountDetails(account);
	}
}
