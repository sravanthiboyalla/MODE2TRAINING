package com.hcl.pp.demoProject.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.pp.demoProject.model.Account;

@Repository

public interface AccountDao extends CrudRepository<Account, String> {

} 
