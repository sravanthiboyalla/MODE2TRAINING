package com.hcl.pp.demoProject.services.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.demoProject.Dao.BenifitDao;
import com.hcl.pp.demoProject.model.Benifits;

@Service
public class BenifitService {

	@Autowired
	BenifitDao benifitDao;
	//this is used to add data to the database
	public void addBenifitDetails(Benifits benifit) {
		// TODO Auto-generated method stub
		benifitDao.save(benifit);
	}
	//this method is used to get the details of particular record based on ifsccode
	public Optional<Benifits> getBenifisDetails(String ifscCode) {
		// TODO Auto-generated method stub
		return benifitDao.findByIfscCode(ifscCode);
	}
	//this is used to get the details of particular record based on ifsccode and custId
	public Optional<Benifits> getBenifisDetails(String ifscCode, Integer custId) {
		// TODO Auto-generated method stub
		return benifitDao.findByIfscCodeAndCustId(ifscCode, custId);
	}

}
