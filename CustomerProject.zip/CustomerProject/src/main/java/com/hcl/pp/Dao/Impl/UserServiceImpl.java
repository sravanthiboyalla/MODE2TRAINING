package com.hcl.pp.Dao.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.Dao.Customer.CustomerService;
import com.hcl.pp.model.Customer;
@Service("CustomerService")
public class UserServiceImpl implements CustomerService{
	
	@Autowired
    UserDaoImpl customerDao;
	@Override
	public void addUser(Customer customer)
	{
		customerDao.addUser(customer);
	}
	
}
