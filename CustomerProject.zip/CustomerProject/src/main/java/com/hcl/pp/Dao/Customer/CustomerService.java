package com.hcl.pp.Dao.Customer;

import com.hcl.pp.model.Customer;

public interface CustomerService {
	public void addUser(Customer customer);
}
