package com.hcl.pp.Dao.Customer;

import com.hcl.pp.model.Customer;

public interface CustomerDao{
	public void addUser(Customer customer);
}
