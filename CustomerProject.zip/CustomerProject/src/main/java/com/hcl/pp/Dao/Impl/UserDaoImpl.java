package com.hcl.pp.Dao.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pp.Dao.Customer.CustomerDao;
import com.hcl.pp.model.Customer;

public class UserDaoImpl implements CustomerDao{
	 @Autowired JdbcTemplate jdbcTemplate;
	 public void addUser(Customer customer)
	 {
		 String sql = "INSERT INTO customer" +
					"(name,age,phonenumber,emailid,job,accountNumber) VALUES (?,?,?,?,?,?)";
					 
				jdbcTemplate.update(sql, new Object[] {customer.getName(),customer.getAge(),customer.getPhoneNumber(),
						customer.getEmailId(),customer.getJob(),customer.getAccountNumber()
				});
	 }
}
