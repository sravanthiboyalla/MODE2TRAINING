package com.hcl.pp;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.hcl.pp.Dao.Impl.UserDaoImpl;
import com.hcl.pp.model.Customer;


@Controller
public class CustomerController {
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	@Autowired
	UserDaoImpl customerService;

	private Map<String,Customer> customers = null;
	//@Autowired
	//@Qualifier("UserValidators")

	private Validator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	public CustomerController() {
		//users = new HashMap<String, User>();
		customers=new HashMap<String,Customer>();
		
	}
	@ModelAttribute("customer")
	public Customer createUserModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new Customer();
	}
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String register() {
		return "login";
	}
	@RequestMapping(value = "/customer/login", method = RequestMethod.GET)
	public String saveUserPage(Model model) {
		logger.info("Returning customerlogin.jsp page");
		model.addAttribute("customer", new Customer());
		return "login";
	}
	@RequestMapping(value = "/customer/login.do", method = RequestMethod.POST)
	public String saveUserAction(@ModelAttribute("customer") @Validated Customer customer, BindingResult bindingResult,
			Model model) {
		System.out.println(customer.getAge());
		customerService.addUser(customer);
		if (customer.getAge()<21) {
			logger.info("Returning userregn.jsp page");
			return "login";
		}
		logger.info("Returning custSaveSuccess.jsp page");
		model.addAttribute("customer",customer);

		return "success";
	}
}
